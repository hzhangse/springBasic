package com.javatrian.aop;

public interface BService {  
    
    public void fooA(String _msg);  
  
    public void barA();  
}  