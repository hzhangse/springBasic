package com.javatrian.aop;

public interface AService {  
    
    public void fooA(String _msg);  
  
    public void barA();  
}  