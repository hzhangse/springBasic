package com.javatrian.spring;

public class HelloWorldSpring {
	private String sayContent;
	
	public String sayHello() {
		System.out.println("HelloWorldSpring Say:Hello World");
		return "Hello World";
	}
}
