package Demo;

public interface Hello {
	public Random getRandom();
    public abstract Random createRandom();
}
