package com.javatrian.spring;

public class HelloWorldSpring {
	public String sayHello() {
		System.out.println("Hello World");
		return "Hello World";
	}
}
